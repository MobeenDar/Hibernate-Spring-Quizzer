/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizer;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "questions")
public class questions implements Serializable {

    @Id
    private int quesNum;
    private String quesContent;
    private int quesOptions;
    private int quesCorrectOptions;
    private int quesMaxScore;

    public int getquesNum() {
        return this.quesNum;
    }

    public void setquesNum(int quesNum) {
        this.quesNum = quesNum;
    }
    
    public String getquesContent() {
        return this.quesContent;
    }

    public void setquesContent(String quesContent) {
        this.quesContent = quesContent;
    }
}

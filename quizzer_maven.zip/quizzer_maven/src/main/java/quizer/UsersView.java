/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizer;

public class UsersView {
      public void printUsersDetails(int userId, String userPassword, String userRole, int userScore){
      System.out.println("Your ID: " + userId);
      System.out.println("You are a: " + userRole);
      System.out.println("Your Score: " + userScore);
   }
}

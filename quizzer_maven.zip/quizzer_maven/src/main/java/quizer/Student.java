/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizer;

public class Student {
    private String stName;
    private int stId;
    private String stPassword;
    private Users model;
    private UsersView view;
    private UsersController controller;
}

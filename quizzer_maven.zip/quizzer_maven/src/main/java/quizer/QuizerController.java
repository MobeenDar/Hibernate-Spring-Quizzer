
package quizer;

public class QuizerController {
    private final Quizer model;
    private final QuizerView view;

   public QuizerController(Quizer model, QuizerView view){
      this.model = model;
      this.view = view;
   }

   public void setQuizTitle(String title){
      model.setTitle(title);		
   }

   public String getQuizName(){
      return model.getTitle();		
   }

   public void setQuizDescription(String description){
      model.setDescription(description);		
   }

   public String getQuizDescription(){
      return model.getDescription();		
   }

   public void updateView(){				
      view.printQuizDetails(model.getTitle(), model.getDescription());
   }	
}

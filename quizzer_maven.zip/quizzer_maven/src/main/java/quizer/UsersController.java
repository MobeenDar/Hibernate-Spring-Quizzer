
package quizer;

public class UsersController {
    private final Users model;
    private final UsersView view;

   public UsersController(Users model, UsersView view){
      this.model = model;
      this.view = view;
   }

   public void setUsersControllerId(int id){
      model.setUsersId(id);
   }

   public int getUsersControllerId(){
      return model.getUsersId();		
   }

   public void setUsersControllerPassword(String pass){
      model.setUsersPassword(pass);	
   }

   public String getUsersControllerPassword(){
      return model.getUsersPassword();		
   }
   
   public void setUsersControllerRole(String role){
      model.setUsersRole(role);		
   }

   public String getUsersControllerRole(){
      return model.getUsersRole();		
   }
   
   public void setUsersControllerScore(int score){
      model.setUsersScore(score);		
   }

   public int getUsersControllerScore(){
      return model.getUsersScore();		
   }

   public void updateView(){				
      view.printUsersDetails(model.getUsersId(), model.getUsersPassword(),model.getUsersRole(),model.getUsersScore());
   }
}


package quizer;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name= "Users")
public class Users implements Serializable {
    @Id
    int userId;
    String password;
    String userRole;
    int score;
    
    public void setUsersId(int id){
    this.userId = id;
    }
   
    public int getUsersId(){
    return this.userId;
    }
    
    public void setUsersPassword(String password){
        this.password = password;
    }
    
    public String getUsersPassword(){
        return this.password;
    }
    
    public void setUsersRole(String role){
        this.userRole = role;
    }
    
    public String getUsersRole(){
        return this.userRole;
    }
    
    public void setUsersScore(int score){
        this.score = score;
    }
    
    public int getUsersScore(){
        return this.score;
    }
}

package DaoPackage;

import quizer.*;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.service.ServiceRegistry;
//import pk.edu.nust.seecs.advprog.hiberate5example.model.Employee;
//import pk.edu.nust.seecs.advprog.hiberate5example.util.HibernateUtil;

public class UserDao {
	static ServiceRegistry  serviceRegistry ;
	static SessionFactory sessionFactory;
    static Session session;
	
	public UserDao(){
		// TODO Auto-generated method stub
        sessionFactory = HibernateUtil.getSessionFactory();
        session = sessionFactory.openSession();
        //nested Transactions are not supported. Once you have started transaction here
        // can't do that in the saveEmployee method.
        //session.beginTransaction();
	}
	
	public void saveUser(List<Users> newUserList){
		Transaction t=session.beginTransaction();  
            for (Users newUserList1 : newUserList) {
                session.persist((Users) newUserList1);
            }
      		t.commit(); 
	}

	public void printUsers()
	{
		List<Users> userList = session.createQuery("from users").list();
		Iterator<Users> it = userList.iterator();
		Users tempUser;
		for(;it.hasNext(); )
		{
			tempUser = it.next();
			System.out.println(tempUser);
		}
	}
	
	public void closeSession()
	{
        session.close();
        sessionFactory.close();
	}
}


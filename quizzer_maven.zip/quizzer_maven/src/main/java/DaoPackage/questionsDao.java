
package DaoPackage;

import quizer.*;

/**
 *
 * @author Mubeen Akhtar
 */
public class questionsDao {
    
}

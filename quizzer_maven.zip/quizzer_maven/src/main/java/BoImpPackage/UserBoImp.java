/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BoImpPackage;


import java.util.ArrayList;
import java.util.List;
import BoPackage.UserBo;
import DaoPackage.UserDao;
import quizer.Instructor;
import quizer.Users;
import quizer.Student;


public class UserBoImp implements UserBo {
    public List<Users> userRoster;

    public UserBoImp() {
        userRoster = new ArrayList<>();
    }

    @Override
    public int addUser(int id) {
        Users tempUser = new Users();
        tempUser.setUsersId(id);

        userRoster.add(tempUser);
        return userRoster.indexOf(tempUser);
    }

//    @Override
//    public int addRegularEmployee(int empIndex, float salary, int bonus) {
//
//        Regular_Employee tempRegEmp = new Regular_Employee();
//        tempRegEmp.setSalary(salary);
//        tempRegEmp.setBonus(bonus);
//        employeeRoster.add(empIndex,tempRegEmp);
//        return employeeRoster.indexOf(tempRegEmp);
//    }
//
//    @Override
//    public int addContractEmployee(int empIndex, float pay_per_hour, String contract_period) {
//
//        Contract_Employee tempConEmp = new Contract_Employee();
//        tempConEmp.setContract_period(contract_period);
//        tempConEmp.setPay_per_hour(pay_per_hour);
//        employeeRoster.add(empIndex,tempConEmp);
//        return employeeRoster.indexOf(tempConEmp);
//    }

    @Override
    public void saveUsers() {
        UserDao userD = new UserDao();
        userD.saveUser(userRoster);
    }
}

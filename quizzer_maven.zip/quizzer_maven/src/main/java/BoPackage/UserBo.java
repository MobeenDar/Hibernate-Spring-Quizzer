/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BoPackage;

public interface UserBo {

    //int addContractEmployee(int empIndex, float pay_per_hour, String contract_period);

    int addUser(int userId);

    //int addRegularEmployee(int empIndex, float salary, int bonus);

    void saveUsers();
    
}

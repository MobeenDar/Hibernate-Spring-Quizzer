/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainPackage;

import BoPackage.UserBo;
import BoPackage.UserBoImp;

/**
 *
 * @author deser_000
 */
public class quizerMain {
    private UserBo employeeHandler = new UserBoImp();
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        quizerMain hbt = new quizerMain();
        hbt.doAll();
    }
    
    /**
     * Perform all action here
     */
    public void doAll(){
        int User1Id = employeeHandler.addUser("fahad");
        int User2Id = employeeHandler.addUser("Obaid");
        int User3Id = employeeHandler.addUser("Zohaib");
        int User4Id = employeeHandler.addUser("Sadaf");
        
        employeeHandler.addRegularEmployee(User1Id, 1.0f , 0);
        employeeHandler.addContractEmployee(User2Id, 0.3f , "1 year");
        employeeHandler.addContractEmployee(User3Id, 0.2f , "1 year");
        employeeHandler.addContractEmployee(User4Id, 0.6f , "2 years");
        
        
        employeeHandler.saveEmployees();
    }
}
